import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


file_path = 'd:/pyhton/university_data.csv'
df = pd.read_csv(file_path)

plt.figure(figsize=(15, 10))

plt.subplot(2, 2, 1)
sns.countplot(x='Gender', data=df, palette='viridis')
plt.title('1. Male vs Female Faculty Count')


plt.subplot(2, 2, 2)
df['Qualification'].value_counts().plot.pie(autopct='%1.1f%%', colors=['gold', 'lightblue'], startangle=140)
plt.title('2. Faculty Qualification Percentage')
plt.ylabel('') 


plt.subplot(2, 2, 3)
sns.countplot(y='Department', data=df, color='salmon')
plt.title('3. No. of Faculty in Each Department')

plt.subplot(2, 2, 4)
sns.countplot(x='Qualification', data=df, palette='pastel')
plt.title('4. Count of PhD vs MS Holders')


plt.tight_layout()
plt.show()
